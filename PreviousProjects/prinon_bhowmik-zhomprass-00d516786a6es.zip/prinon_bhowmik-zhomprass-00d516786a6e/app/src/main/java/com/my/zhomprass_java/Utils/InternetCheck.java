package com.my.zhomprass_java.Utils;


public final class  InternetCheck{



}
