package com.my.zhomprass_java.Models;

public class Members {
    private int member;

    public Members(int member) {
        this.member = member;
    }

    public int getMember() {
        return member;
    }
}
