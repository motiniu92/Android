package com.my.zhomprass_java.Utils;

public class Config {
    public static String IMAGE_LINE ="https://zhomprass.com/app1/";
    public static final String SLIDER_IMAGE_LINE ="https://zhomprass.com/photo/";
    public static  Config INSTANCE;
}
