package com.my.zhomprass_java.Models;

public class Product_count {

    String total_product;

    public Product_count(String total_product) {
        this.total_product = total_product;
    }

    public String getTotal_product() {
        return total_product;
    }
}
